var url = 'https://koopreynders.github.io/frontendvoordesigners/opdracht3/json/movies.json';

var request = new XMLHttpRequest();

var main = document.querySelector("main");
request.open('GET', url);
request.responseType = 'json';
request.send();

//LOAD listener van het XMLHttpRequest
//wordt uitgevoerd als de json data geladen is
request.addEventListener("load", function(){

  var data = request.response;

  for(var i = 0; i < data.length; i++) {
      var film = data[i];

      var article = document.createElement("article");
      var filmCover = document.createElement('img');
      var titel = document.createElement("h2");
      var simplePlot = document.createElement("p");

      //for loop voor de genres
      //for loop in data.genres
      var genres = film.genres;
      var classlist = '';
      // console.log("genres",genres)

      for(var j=0; j<genres.length;j++){
        console.log(genres[j])
        classlist += genres[j] + " ";
      }



      article.setAttribute("class",classlist);

      filmCover.src = film.cover;
      titel.textContent = film.title;
      simplePlot.textContent = film.simple_plot;

 //zorgt dat de elementen in een article komen te staan
      article.appendChild(filmCover);
      article.appendChild(titel);
      article.appendChild(simplePlot);

  //zet de articles in de DOM
      main.appendChild(article);
  }

});
//Buttons
let dramaButton = document.querySelector('#Drama');
let horrorButton = document.querySelector('#Horror');
let thrillerButton = document.querySelector('#Thriller');

//GENRES
var genresDrama = document.querySelectorAll('.Drama');
console.log(genresDrama)
var genresHorror = document.querySelectorAll('.Horror');
var genresThriller = document.querySelectorAll('.Thriller');

function showAllDrama() {
  genresDrama[0].style.display = 'none';

  for (let i = 0; i < genresDrama; i++){
    genresDrama[i].style.display = 'block';
  }
  for (let x = 0; x < genresHorror; x++){
    genresHorror[x].style.display = 'none';
  }
  for (let y = 0; y < genresThriller; y++){
    genresThriller[y].style.display = 'none';
  }
}

// function showAllHorror(){
//
// }
//
// function showAllThriller(){
//
// }

dramaButton.addEventListener('click', showAllDrama);
horrorButton.addEventListener('click', showAllHorror);
thrillerButton.addEventListener('click', showAllThriller);
